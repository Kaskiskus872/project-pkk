const api_baseUrl = 'https://project-pkk-production.up.railway.app';
    let allProducts = [];

        function createProductCard(product) {
        const slide = document.createElement('div');
        slide.className = 'swiper-slide product-item';

        // Batasi deskripsi maksimal 25 karakter, tambahkan ... jika lebih
        let shortDesc = product.description;
        if (shortDesc.length > 30) {
            shortDesc = shortDesc.substring(0, 25) + '...';
        }
        slide.innerHTML = `
            <img src="${product.imageUrl || 'https://via.placeholder.com/250'}" alt="${product.name}" />
            <h3>${product.name}</h3>
            <p>${shortDesc}</p>
        `;

        // Klik seluruh card -> munculin modal
        slide.addEventListener('click', () => {
            showProductModalById(product.id);
        });

        return slide;
        }


        function addPopupListeners() {
        document.querySelectorAll('.buy-button').forEach(button => {
            button.addEventListener('click', () => {
            const id = button.getAttribute('data-id');
            showProductModalById(id);
            });
        });
        }

        function showProductModalById(id) {
        console.log('Modal Triggered for ID:', id); // <== Tambahin ini
        const product = allProducts.find(p => p.id == id);
        const modal = document.getElementById("productModal");
        document.getElementById("modalImage").src = product.imageUrl || 'https://via.placeholder.com/250';
        document.getElementById("modalTitle").textContent = product.name;
        document.getElementById("modalDescription").textContent = product.description;
        document.getElementById("modalPrice").textContent = `Rp.${product.price}`;

        // Tombol di dalam modal: "Beli" dan "Keranjang"
        document.getElementById("modalBuyBtn").onclick = () => {
            alert(`Membeli produk: ${product.name}`);
        };

        document.getElementById("modalCartBtn").onclick = () => {
            if (!isLoggedIn) {
            alert('Silakan login dulu untuk menambahkan ke keranjang.');
            return;
            }

            const quantity = prompt('Masukkan jumlah produk:');
            if (quantity && !isNaN(quantity)) {
            addToCart(product.id, parseInt(quantity));
            } else {
            alert('Jumlah tidak valid.');
            }
        };

        // Tambahkan tampilan rating dan feedback
        const modalImage = document.querySelector('.popup-image');
        // Hapus elemen rating lama jika ada
        const oldRatingSection = document.getElementById('ratingSection');
        if (oldRatingSection) oldRatingSection.remove();

        // Buat section baru untuk rating & feedback
        const ratingSection = document.createElement('div');
        ratingSection.id = 'ratingSection';
        ratingSection.style.marginTop = '32px';
        ratingSection.style.gridColumn = '1 / -1'; // full width jika pakai grid
        ratingSection.innerHTML = `
            <h4>Ulasan Produk</h4>
            <div id="ratingsList">Memuat ulasan...</div>
            <div id="addRatingForm" style="margin-top:16px;${isLoggedIn ? '' : 'display:none;'}">
                <label>Beri Rating:</label>
                <div id="starInput">
                    ${[1,2,3,4,5].map(i => `<span class="star" data-value="${i}">&#9734;</span>`).join('')}
                </div>
                <textarea id="feedbackInput" rows="2" placeholder="Tulis ulasan..." style="width:100%;margin-top:8px;"></textarea>
                <button id="submitRatingBtn" style="margin-top:8px;">Kirim Ulasan</button>
            </div>
            <div id="loginToRate" style="${isLoggedIn ? 'display:none;' : ''}color:#888;margin-top:8px;">Login untuk memberi ulasan.</div>
        `;
        // Sisipkan ratingSection SETELAH .popup-body (bukan di dalamnya)
        const popupBody = document.querySelector('.popup-body');
        popupBody.parentNode.insertBefore(ratingSection, popupBody.nextSibling);

        // Fetch dan tampilkan rating
        fetch(`${api_baseUrl}/ratings/${product.id}`)
            .then(res => res.json())
            .then(ratings => {
                const ratingsList = document.getElementById('ratingsList');
                if (!ratings || !ratings.length) {
                    ratingsList.innerHTML = '<em>Belum ada ulasan.</em>';
                } else {
                    ratingsList.innerHTML = ratings.map(r => `
                        <div style="border-bottom:1px solid #eee;padding:6px 0;">
                            <b>${r.user?.username || 'User'}</b> - 
                            <span style="color:gold;">${'★'.repeat(r.rating)}${'☆'.repeat(5-r.rating)}</span><br/>
                            <span>${r.feedback}</span>
                        </div>
                    `).join('');
                }
            });

        // Star rating input interaksi
        if (isLoggedIn) {
            let selectedRating = 0;
            document.querySelectorAll('#starInput .star').forEach(star => {
                star.addEventListener('mouseover', function() {
                    const val = +this.getAttribute('data-value');
                    document.querySelectorAll('#starInput .star').forEach((s, i) => {
                        s.innerHTML = i < val ? '&#9733;' : '&#9734;';
                    });
                });
                star.addEventListener('mouseout', function() {
                    document.querySelectorAll('#starInput .star').forEach((s, i) => {
                        s.innerHTML = i < selectedRating ? '&#9733;' : '&#9734;';
                    });
                });
                star.addEventListener('click', function() {
                    selectedRating = +this.getAttribute('data-value');
                    document.querySelectorAll('#starInput .star').forEach((s, i) => {
                        s.innerHTML = i < selectedRating ? '&#9733;' : '&#9734;';
                    });
                });
            });
            document.getElementById('submitRatingBtn').onclick = async function() {
                const feedback = document.getElementById('feedbackInput').value.trim();
                if (!selectedRating) return alert('Pilih rating bintang!');
                if (!feedback) return alert('Tulis ulasan terlebih dahulu!');
                try {
                    const res = await fetch(`${api_baseUrl}/ratings/${product.id}`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            Authorization: `Bearer ${token}`
                        },
                        body: JSON.stringify({ rating: selectedRating, feedback })
                    });
                    if (res.ok) {
                        alert('Ulasan berhasil dikirim!');
                        showProductModalById(product.id); // Refresh ulasan
                    } else {
                        const err = await res.json();
                        alert('Gagal mengirim ulasan: ' + (err.message || '')); 
                    }
                } catch (e) {
                    alert('Gagal mengirim ulasan!');
                }
            }
        }

        document.getElementById("productModal").style.display = "flex";
        }

    document.querySelector(".close-button").addEventListener("click", () => {
    document.getElementById("productModal").style.display = "none";
    });

    function addCartButtonsListener() {
    document.querySelectorAll('.cart-button').forEach(button => {
        button.addEventListener('click', (e) => {
        if (!isLoggedIn) {
            alert('Silakan login terlebih dahulu untuk menambahkan ke keranjang.');
            return;
        }

        const productId = e.target.getAttribute('data-id');
        const quantity = prompt('Masukkan jumlah produk yang ingin ditambahkan ke keranjang:');

        if (quantity && !isNaN(quantity)) {
            addToCart(productId, parseInt(quantity));
        } else {
            alert('Jumlah tidak valid.');
        }
        });
    });
    }

    async function addToCart(productId, quantity) {
    try {
        const response = await fetch(`${api_baseUrl}/cart`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ productId, quantity })
        });

        if (response.ok) {
        alert('Produk berhasil ditambahkan ke keranjang.');
        } else {
        alert('Gagal menambahkan produk ke keranjang.');
        }
    } catch (error) {
        console.error('Error adding to cart:', error);
    }
    }

    function initSwiper(selector, direction = 'right') {
        return new Swiper(selector, {
            slidesPerView: 4,
            spaceBetween: 10,
            loop: true,
            speed: 2000,
            allowTouchMove: false,
            navigation: {
                nextEl: selector + ' .swiper-button-next',
                prevEl: selector + ' .swiper-button-prev',
            },
            pagination: {
                el: selector + ' .swiper-pagination',
                clickable: true,
            },
            autoplay: {
                delay: 1, // 1ms supaya jalan terus
                disableOnInteraction: false,
                reverseDirection: direction === 'left',
                pauseOnMouseEnter: false,
            },
        });
    }

    async function fetchProducts() {
    try {
        const response = await fetch(`${api_baseUrl}/products`);
        const data = await response.json();

        if (!data.data || data.data.length === 0) {
        document.querySelector('.product-list.latest').innerHTML = '<p>No products found.</p>';
        document.querySelector('.product-list.best-seller').innerHTML = '<p>No products found.</p>';
        document.querySelector('.product-list.all').innerHTML = '<p>No products found.</p>';
        return;
        }

        allProducts = data.data;

        // Sort latest by createdAt DESC (paling baru di depan)
        const latestProducts = [...allProducts]
            .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
            .slice(0, 4);

        // Fetch ratings for best seller sort
        const ratingsRes = await fetch(`${api_baseUrl}/ratings/all`);
        const ratingsData = await ratingsRes.json();
        // ratingsData: array of { productId, avgRating }
        // Gabungkan avgRating ke allProducts
        const productsWithRating = allProducts.map(p => {
            const ratingObj = ratingsData.find(r => r.productId === p.id);
            return { ...p, avgRating: ratingObj ? ratingObj.avgRating : 0 };
        });
        // Sort best seller by avgRating DESC, hanya produk yang punya ulasan
        const bestSellerProducts = [...productsWithRating]
            .filter(p => p.avgRating > 3)
            .sort((a, b) => b.avgRating - a.avgRating)
            .slice(0, 4);

        // Render latest
        document.querySelector('.product-list.latest').innerHTML = '';
        latestProducts.forEach(product => {
            const card = createProductCard(product);
            document.querySelector('.product-list.latest').appendChild(card);
        });

        // Render best seller
        document.querySelector('.product-list.best-seller').innerHTML = '';
        bestSellerProducts.forEach(product => {
            const card = createProductCard(product);
            document.querySelector('.product-list.best-seller').appendChild(card);
        });

        // Render all
        document.querySelector('.product-list.all').innerHTML = '';
        allProducts.forEach(product => {
            const card = createProductCard(product);
            document.querySelector('.product-list.all').appendChild(card);
        });

        addCartButtonsListener();
        addPopupListeners();
        // Destroy Swiper instance jika sudah ada (untuk mencegah duplikasi)
        if (window.latestSwiper) window.latestSwiper.destroy(true, true);
        if (window.bestSellerSwiper) window.bestSellerSwiper.destroy(true, true);
        window.latestSwiper = initSwiper('.latest-swiper', 'right'); // otomatis ke kanan
        window.bestSellerSwiper = initSwiper('.best-seller-swiper', 'left'); // otomatis ke kiri
    } catch (error) {
        console.error('Error fetching products:', error);
    }
    }

    const token = localStorage.getItem('jwtToken');
    const isLoggedIn = !!token;

    if (isLoggedIn) {
    document.getElementById('logout').style.display = 'inline';
    document.getElementById('loginLink').style.display = 'none';
    document.getElementById('cartLink').style.display = 'inline';

    const payload = JSON.parse(atob(token.split('.')[1]));
    if (payload.role === 'admin') {
        document.getElementById('dashboardLink').style.display = 'inline';
    }
    } else {
    // Tampilkan login kalau belum login
    document.getElementById('loginLink').style.display = 'inline';
    document.getElementById('logout').style.display = 'none';
    document.getElementById('cartLink').style.display = 'none';
    document.getElementById('dashboardLink').style.display = 'none';
    }


    // === LOGOUT FUNCTION ===
    document.getElementById('logout').addEventListener('click', function () {
    localStorage.removeItem('jwtToken');
    alert('Berhasil logout!');
    window.location.href = 'login.html'; // Ubah sesuai rute login lo
    });

    fetchProducts();